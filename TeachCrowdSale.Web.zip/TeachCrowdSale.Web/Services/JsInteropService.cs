namespace TeachCrowdSale.Web.Services;

public class JsInteropService
{
    
}