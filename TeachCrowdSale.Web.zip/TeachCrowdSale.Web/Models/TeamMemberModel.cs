namespace TeachCrowdSale.Web.Models;

public class TeamMemberModel
{
    
}