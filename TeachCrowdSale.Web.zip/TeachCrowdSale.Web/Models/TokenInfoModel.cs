namespace TeachCrowdSale.Web.Models;

public class TokenInfoModel
{
    
}