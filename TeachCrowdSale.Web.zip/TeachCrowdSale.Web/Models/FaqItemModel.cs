namespace TeachCrowdSale.Web.Models;

public class FaqItemModel
{
    public string Id { get; set; }
    public string Category { get; set; }
    public string Question { get; set; }
    public string Answer { get; set; }
}