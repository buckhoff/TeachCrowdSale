using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TeachCrowdSale.Web.Components.Pages;

public class _Host : PageModel
{
    public void OnGet()
    {
        
    }
}